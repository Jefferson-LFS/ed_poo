class Conta:

    def __init__(self, cliente, agencia, conta, limite):
        self.__cliente = cliente #Cliente
        self.__agencia = agencia
        self.__conta = conta
        self.__limite = limite
        self.__saldo = 0
    
    def depositar(self, valor):
        self.__saldo += valor

    def sacar(self, valor):
        self.__saldo -= valor

    def get_saldoBanco(self):
        return (self.__saldo + self.__limite)

    def __get_saldoReal(self):
        return self.__saldo
    
    @property
    def cliente(self):
        #return self.__cliente.get_nome()
        #return self.__cliente.nome #property
        return self.__cliente

    def get_titular(self):
        return self.__cliente