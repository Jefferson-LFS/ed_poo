class Moldura:
    def __init__(self, retanguloMaior, retatanguloMenor, custoArea):
        self.__retanguloMaior = retanguloMaior
        self.__retanguloMenor = retatanguloMenor
        self.__custoArea = custoArea
    
    def get_retanguloMaior(self):
        return self.__retanguloMaior

    def get_retanguloMenor(self):
        return self.__retanguloMenor
    
    def set_retanguloMaior(self, novoR):
        self.__retanguloMaior = novoR

    def set_retanguloMenor(self, novoR):
        self.__retanguloMenor = novoR

    def area(self):
        return (self.__retanguloMaior.area() - self.__retanguloMenor.area())

    def custo(self):
        return self.__custoArea * self.area()