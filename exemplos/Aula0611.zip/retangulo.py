class Retangulo:

    def __init__(self, base, altura):
        self.__base = base
        self.__altura = altura

    def get_altura(self):
        return self.__altura

    def get_base(self):
        return self.__base

    def set_altura(self, novaAltura):
        self.__altura = novaAltura
    
    def set_base(self, novaBase):
        self.__base = novaBase

    def __str__(self):
        return "Base: {} - Altura:{}".format(self.__base, self.__altura)

    def area(self):
        return self.__altura * self.__base