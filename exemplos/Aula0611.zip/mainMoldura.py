from moldura import Moldura
from retangulo import Retangulo


def main():
    rMaior = Retangulo(30, 10)
    rMenor = Retangulo(26, 6)

    mold = Moldura(rMaior, rMenor, 15.0)
    print (mold.area())

    print("Custo da Moldura: R$ {}".format(mold.custo()))

main()