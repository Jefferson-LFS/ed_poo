class Cliente:

    def __init__(self, nome, cpf, dataNascimento, endereco):
        self.__nome = nome
        self.__cpf = cpf
        self.__dataNascimento = dataNascimento
        self.__endereco = endereco

    @property
    def nome(self):
        return self.__nome

    @nome.setter
    def nome(self, novoNome):
        self.__nome = novoNome

    def get_nome(self):
        return self.__nome
    
    def set_nome(self, novoNome):
        self.__nome = novoNome

    
    def __str__(self):
        saida = "Nome:"+str(self.__nome)+", CPF:"+str(self.__cpf)+", Data de Nascimento:"+str(self.__dataNascimento)+", Endereco: "+str(self.__endereco)
        return saida