from conta import Conta
from cliente import Cliente

cliente = Cliente("Alana", 111111, "20/08/2000", "Tokio")
print(cliente.nome)
cliente.nome = "Aline"


c = Conta(cliente, 221, 123, 100)

print("Saldo: R$"+str(c.get_saldoBanco()) )
c.depositar(2000)
print("Saldo: R$"+str(c._Conta__get_saldoReal()) )

print(c.cliente)