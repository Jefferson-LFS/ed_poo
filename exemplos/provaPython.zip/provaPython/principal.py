from pilha import Pilha

def main():
    pilhaTeste =  Pilha()
    desbalanceada = False

    expressao = str(raw_input("Digite sua expressao:"))
    #expressao = "(()()"
    for letra in expressao:
        if (letra == '('):
            pilhaTeste.push('(')
        elif(letra == ')' ):
            if (pilhaTeste.isEmpty() == False):
                pilhaTeste.pop()
            else:
                desbalanceada = True

    if (pilhaTeste.len() == 0) and (desbalanceada == False):
        print("Parenteses Balanceados")
    else:
        print("Parenteses Desbalanceados")

main()