from pilha import Pilha

def main():
    pilha1 = Pilha()
    pilha2 = Pilha()
    pilha2_aux = Pilha()

    pilha1.push("abc")
    pilha1.push("def")
    pilha1.push("abc")

    pilha2.push("abc")
    pilha2.push("def")
    pilha2.push("abc")
    
    print(pilha1.getPilha())
    print(pilha2.getPilha())

    if (pilha1.len() != pilha2.len()):
        return "nao sao palindromos"
    else:
        j = pilha2.len()
        for i in range(j):
            aux = pilha2.getPilha()[j-1]
            pilha2_aux.push(aux)
            j -= 1

    print(pilha2_aux.getPilha())
        
    palindromos = True
    for obj in range(pilha1.len()):
        if (pilha1.pop() != pilha2_aux.pop()):
            palindromos = False
            return "nao sao palindromos"

    if palindromos:
        return "Sao palindromos"
    
print(main())
  