from listaencadeadacircular import ListaEncadeadaCircular

def main():
    
    listaC = ListaEncadeadaCircular()
    print("Lista:"+listaC.mostrar())

    listaC.inserirNoInicio(22)
    listaC.inserirNoInicio(123)
    listaC.inserirNoFinal(124)
    print("Lista:"+listaC.mostrar())

    listaC.remove(124)
    print("Lista:" + listaC.mostrar())
    listaC.remove(10)
    listaC.remove(123)
    print("Lista:"+listaC.mostrar())
    listaC.remove(22)
    print("Lista:"+listaC.mostrar())


main()
