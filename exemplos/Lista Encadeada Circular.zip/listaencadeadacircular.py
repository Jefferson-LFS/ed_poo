from node import No

class ListaEncadeadaCircular(object):

    def __init__(self):
        self.cabeca = None
        self.cauda = None
        self.tam = 0

    def inserirNoInicio(self, valor):
        new_node = No()
        new_node.setValor(valor)
        new_node.setProximo(self.cabeca)
        self.cabeca = new_node

        if self.tam == 0:
            self.cauda = new_node
        self.cauda.setProximo(self.cabeca)
        self.tam += 1

    #adicionar ao final da lista circular
    def inserirNoFinal(self, valor):
        new_node = No()
        new_node.setValor(valor)
        if self.tam == 0:
            self.cabeca = new_node
        else:
            self.cauda.setProximo(new_node)
        self.cauda = new_node
        self.cauda.setProximo(self.cabeca)
        self.tam += 1

    def __iter__(self):
        node = self.cabeca
        stop = 1
        while ((node!= None) and (stop==1)):
            yield node
            if node == self.cauda:
                stop = 0
            node = node.getProximo()

    def mostrar(self):
        items = ''
        for item in self.__iter__():
            items += str(item.getValor()) + ' '
        return items

    def remove(self, valor):
        prev_node = None
        found = False
        for curr_node in self.__iter__():
            if valor == curr_node.getValor():
                found = True
                if prev_node:
                    prev_node.setProximo(curr_node.getProximo())
                    if curr_node == self.cauda:
                        self.cauda = prev_node
                else:
                    if self.tam == 1:
                        self.__init__()
                        return None
                    else:
                        self.cabeca = curr_node.getProximo()
                        self.cauda.setProximo(self.cabeca)

                self.tam = self.tam - 1
            prev_node = curr_node
        if not found:
            print("Valor "+str(valor)+" não encontrado na lista encadeada circular.")