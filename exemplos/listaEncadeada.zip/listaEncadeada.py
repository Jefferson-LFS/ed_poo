import node

class ListaEncadeada(object):

    def __init__(self):
        self.cabeca = None
        self.cauda = None

    def vazia(self):
                '''Se primeiro e ultimo estiverem na mesma
                posicao, isso quer dizer que a lista esta vazia, pois
                quando um item eh adicionado um desses "ponteiros" sao movidos.'''
                return self.cabeca==self.cauda


    def inserirNo(self, item):
       no = node.No()
       no.setValor(item)

       if (self.cabeca == None and self.cauda == None):
           self.cabeca = no
           self.cauda = no
       else:
           self.cauda.proximo = no

       no.setProximo(None)
       self.cauda = no

    
    def printLista(self):
        no = self.cabeca
       
        while (no != None):
            print(no.getValor())
            no = no.proximo


    def removerNo(self, item):
            noAtual = self.cabeca
            anterior = None
            found = False

            while not found:        
                if (noAtual.getValor() == item):
                    found = True
                else:
                    anterior = noAtual
                    noAtual = noAtual.getProximo()
            if (anterior == None):
                self.cabeca = noAtual.getProximo()
            else:
                anterior.setProximo(noAtual.getProximo())
    
    