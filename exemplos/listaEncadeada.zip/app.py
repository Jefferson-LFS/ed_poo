from listaEncadeada import ListaEncadeada


def main():

    lista = ListaEncadeada()
    lista.inserirNo(1)
    lista.inserirNo(2)
    lista.printLista()
    
    print('Lista')
    lista.removerNo(2)
    lista.printLista()

    print('Lista')
    lista.removerNo(1)
    lista.printLista()


main()