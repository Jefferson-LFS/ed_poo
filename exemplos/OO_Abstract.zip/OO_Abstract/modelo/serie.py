from modelo.programa import Programa

class Serie(Programa):
    def __init__(self, nome, ano, temporadas):
        super().__init__(nome, ano)
        self.__temporadas = temporadas


    def get_temporadas(self):
        return self.__temporadas

    def set_temporadas(self, temp):
        self.__temporadas = temp

    def __str__(self):
        return f'Nome: {self.nome} - {self.__temporadas} temporadas - Likes: {self.likes}'

    temporadas = property(get_temporadas, set_temporadas)