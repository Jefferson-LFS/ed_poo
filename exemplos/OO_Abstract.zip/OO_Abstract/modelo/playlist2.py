from collections.abc import MutableSequence

class Playlist:
    pass