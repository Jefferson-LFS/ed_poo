class Programa:
    def __init__(self, nome, ano):
        self.__nome = nome.title()
        self.__ano = ano
        self.__likes = 0

    def get_likes(self):
        return self.__likes

    def set_likes(self, likes):
        self.__likes = likes

    def dar_likes(self):
        self.__likes += 1

    def get_nome(self):
        return self.__nome

    def set_nome(self, nome):
        self.__nome = nome

    def get_ano(self):
        return self.__ano

    def set_ano(self, ano):
        self.__ano = ano

    def __str__(self):
        return f'Nome: {self.__nome} Likes: {self.__likes} Ano:{self.__ano}'

    nome = property(get_nome, set_nome)
    likes = property(get_likes, set_likes)
    ano = property(get_ano, set_ano)