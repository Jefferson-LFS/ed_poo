class Playlist:
    def __init__(self, nome, programas):
        self.__nome = nome
        self.__programas = programas

    def get_nome(self):
        return self.__nome

    def set_nome(self, nome):
        self.__nome = nome

    def get_programas(self):
        return self.__programas

    def set_programas(self, programas):
        self.__programas = programas

    def __getitem__(self, item):
        return self.__programas[item]

    def __len__(self):
        return len(self.__programas)

    nome = property(get_nome, set_nome)
    programas = property(get_nome, set_nome)
