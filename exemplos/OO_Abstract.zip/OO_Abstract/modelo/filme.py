from modelo.programa import Programa

class Filme(Programa):
    def __init__(self, nome, ano, duracao):
        super().__init__(nome, ano)
        self.__duracao = duracao

    def get_duracao(self):
        return self.__duracao

    def set_duracao(self, duracao):
        self.__duracao = duracao

    def __str__(self):
        return f'Nome: {self.nome} - {self.__duracao} min - Likes: {self.likes}'

    duracao = property(get_duracao, set_duracao)