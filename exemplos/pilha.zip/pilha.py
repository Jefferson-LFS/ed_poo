class Pilha(object):
    def __init__(self) :
        self.data = []

    #insere
    def push(self, item) :
        self.data.append(item)

    #remove
    def pop(self) :
        return self.data.pop()

    #topo
    def top(self):
         return (self.data[len(self.data)-1])
    
    def getPilha(self):
         return self.data

    def isEmpty(self) :
        return (self.data == [])

    def len(self):
        return len(self.data)

    #esvaziar
    def clear(self):
         while(len(self.dados) != 0):
             self.dados =  self.dados.pop()

#pilha = Pilha()