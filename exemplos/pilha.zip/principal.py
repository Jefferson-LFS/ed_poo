from pilha import Pilha


pilhaTeste =  Pilha()
pilhaTeste.push(2)
pilhaTeste.push(4)

print(pilhaTeste.getPilha())

pilhaTeste.pop()
print(pilhaTeste.getPilha())