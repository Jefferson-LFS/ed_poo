class Fila(object):
    def __init__(self):
        self.dados = [ ]
        print("Funcao __init__")

    def getFila(self):
        return self.dados
    
    def inserirDado(self,novoValor):
        self.dados.append(novoValor)

    def removerDado(self):
        self.dados.pop(0)
