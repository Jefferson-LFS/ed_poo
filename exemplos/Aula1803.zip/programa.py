import fila

fila1 =  fila.Fila()
print(fila1.getFila())

fila1 =  fila.Fila()
fila1.inserirDado(0)
fila1.inserirDado(1)
fila1.inserirDado(2)
print(fila1.getFila())

fila1.removerDado()
print(fila1.getFila())

