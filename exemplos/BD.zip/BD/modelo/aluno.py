class Aluno:

    def __init__(self, id, mat, nome, end):
        self.__id = id
        self.__mat = mat
        self.__nome = nome
        self.__end = end
        self.__turma = None

    def __str__(self):
        return "Id: "+str(self.__id)+"- Matricula: "+str(self.__mat)+"- Nome: "+str(self.__nome)+"- Endereco: "+str(self.__end)+"- Turma: "+str(self.__turma)

    def get_id(self):
        return self.__id

    def set_id(self, idN):
        self.__id = idN

    def get_mat(self):
        return self.__mat

    def set_mat(self, matN):
        self.__mat = matN

    def get_nome(self):
        return self.__nome

    def set_nome(self, nomeN):
        self.__nome = nomeN

    def get_end(self):
        return self.__end

    def set_end(self, endN):
        self.__end = endN

    def get_turma(self):
        return self.__turma

    def set_turma(self, turmaN):
        self.__turma = turmaN

    id = property(get_id)
    matricula = property(get_mat, set_mat)
    nome = property(get_nome, set_nome)
    endereco = property(get_end, set_end)
    turma = property(get_turma, set_turma)
