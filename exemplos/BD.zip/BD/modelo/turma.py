class Turma:
    def __init__(self, id, sala, periodo):
        self.__id = id
        self.__sala = sala
        self.__periodo =  periodo

    def __str__(self):
        return "[ Id: "+str(self.__id)+"- Sala: "+str(self.__sala)+"- Periodo: "+str(self.__periodo)+"]"

    def get_id(self):
        return self.__id

    def set_id(self, idN):
        self.__id = idN

    def get_sala(self):
        return self.__sala

    def set_sala(self, salaN):
        self.__sala = salaN

    def get_periodo(self):
        return self.__periodo

    def set_periodo(self, periodoN):
        self.__periodo = periodoN

    id = property(get_id)
    sala = property(get_sala, set_sala)
    periodo = property(get_periodo, set_periodo)