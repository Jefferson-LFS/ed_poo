import pymysql

class Database:

    def __init__(self, host, user, password, database):
        self.__localhost = host
        self.__user = user
        self.__pass = password
        self.__database = database
        self.__conexao = self.__connect()


    def __connect(self):
        try:
            self.__conexao = pymysql.connect(
                host=self.__localhost,
                user=self.__user,
                passwd=self.__pass,
                db=self.__database
            )
            return self.__conexao
        except :
            print("Banco não existe")
            return None

    def select_aluno_campo(self, coluna, valor):
        cursor = self.__conexao.cursor()
        query = "SELECT nome FROM aluno WHERE "+str(coluna)+"="+str(valor)
        #query = "SELECT * FROM aluno WHERE matricula='333'"
        print(query)
        cursor.execute(query)

        for x in cursor:
            print(x)

    def inserir_aluno(self, aluno):
        print("Inserindo Aluno")
        cursor = self.__conexao.cursor()
        query = "INSERT INTO aluno (idAluno, matricula, nome, endereco, codTurma) VALUES (%s, %s, %s, %s, %s)"
        cursor.execute(query, (aluno.id, aluno.matricula, aluno.nome, aluno.endereco, aluno.turma.id))
        self.__conexao.commit()
        print("Aluno inserido")

    def inserir_turma(self, turma):
        print("Inserindo turma")
        cursor = self.__conexao.cursor()
        query = "INSERT INTO Turma (idTurma, sala, periodo) VALUES (%s, '%s', '%s')" % (turma.id, turma.sala, turma.periodo)
        cursor.execute(query)
        self.__conexao.commit()
        print("Turma inserida")