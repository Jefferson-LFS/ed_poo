import pymysql

#Versao estruturada - nao quero assim
conexao = pymysql.connect(
        host='localhost',
        user='root',
        passwd='12senha90',
        db='uni'
)

cursor = conexao.cursor()
cursor.execute("SELECT * FROM turma")
#var = 15
#cursor.execute("INSERT INTO Turma (idTurma, sala, periodo) VALUES ("+str(var)+", '"+'lab SI'+"', '"+'tarde'+"')")
#conexao.commit()

for x in cursor:
    print(x)




#https://www.youtube.com/watch?v=92NNhgBP3Ig
#https://www.youtube.com/watch?v=PsvmkXm6Pjw