from bd.bd import Database
from modelo.turma import Turma
from modelo.aluno import Aluno

def main():
    banco = Database('localhost', 'root', '12senha90', 'uni')

    banco.select_aluno_campo('matricula', "333")

    t = Turma(5, "lab Redes convergentes", "tarde")
    #banco.inserir_turma(t)

    a = Aluno(13, "22235", "Lafayette", "Camilo de Holanda")
    a.turma = t
    print(a)

    #banco.inserir_aluno(a)


main()