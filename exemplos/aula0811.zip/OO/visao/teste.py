from modelo.conta import Conta
from modelo.cliente import Cliente


def main():
    cliente = Cliente("Alana", 111111, "20/08/2000", "Tokio")
    cliente.nome = "Leonardo"
    print(cliente.nome)


    c = Conta(cliente, 123-4, 1212-0, 0)
    c.deposita(200)
    print(c.saldo)
    print(c.saldom2)
    #print(c.saldom2)


main()
