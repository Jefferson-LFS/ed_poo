class Cliente:

    def __init__(self, nome, cpf, dataNascimento, endereco):
        self.__nome = nome
        self.__cpf = cpf
        self.__dataNascimento = dataNascimento
        self.__endereco = endereco

    def get_nome(self):
        return self.__nome

    def set_nome(self, novoNome):
        self.__nome = novoNome

    def get_cpf(self):
        return self.__cpf

    def set_cpf(self, novoCpf):
        self.__cpf = novoCpf

    def get_dataNascimento(self):
        return self.__dataNascimento

    def set_dataNascimento(self, novaData):
        self.__dataNascimento = novaData

    def get_endereco(self):
        return self.__endereco

    def set_endereco(self, novoEnd):
        self.__endereco = novoEnd


    #Properties
    nome = property(get_nome, set_nome)
    cpf = property(get_cpf, set_cpf)
    dataNascimento = property(get_dataNascimento, set_dataNascimento)
    endereco = property(get_endereco, set_endereco)



    def __str__(self):
        saida = "Nome:" + str(self.__nome) + ", CPF:" + str(self.__cpf) + ", Data de Nascimento:" + str(
            self.__dataNascimento) + ", Endereco: " + str(self.__endereco)
        return saida