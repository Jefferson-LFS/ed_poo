class Conta:

    def __init__(self, cliente, agencia, conta, limite):
        self.__cliente = cliente  # Cliente
        self.__agencia = agencia
        self.__conta = conta
        self.__limite = limite
        self.__saldo = 0

    def extrato(self):
        print("Saldo de {} do titular {}".format(self.__saldo, self.__titular))

    def deposita(self, valor):
        self.__saldo += valor

    def saca(self, valor):
        self.__saldo -= valor

    def transfere(self, valor, destino):
        self.saca(valor)
        destino.deposita(valor)

    def get_saldoBanco(self):
        return (self.__saldo + self.__limite)

    #Getters e Setters
    def get_cliente(self):
        return self.__cliente

    def set_cliente(self, novoTitular):
        self.__cliente = novoTitular

    def get_agencia(self):
        return self.__agencia

    def get_conta(self):
        return self.__conta

    def get_limite(self):
        return self.__limite

    def set_limite(self, novoLimite):
        self.__limite = novoLimite

    def get_saldo(self):
        return self.__saldo

    def set_saldo(self, novoSaldo):
        self.__saldo = novoSaldo


    #Properties - Modo 1
    @property
    def cliente(self):
        return self.__cliente

    @cliente.setter
    def cliente(self, novoCliente):
        self.__cliente = novoCliente

    @property
    def agencia(self):
        return self.__agencia

    @property
    def conta(self):
        return self.__conta

    @property
    def limite(self):
        return self.__limite

    @limite.setter
    def limite(self, limite):
        self.__limite = limite

    @property
    def saldo(self):
        return self.__saldo

    @saldo.setter
    def saldo(self, novoSaldo):
        self.__saldo = novoSaldo

    #Property - Modo 2
    limitem2 = property(get_limite, set_limite)
    #saldom2 = property(get_saldo, set_saldo)
    saldom2 = property(get_saldoBanco, set_saldo)
    clientem2 = property(get_cliente, set_cliente)
    agenciam2 = property(get_agencia)
    contam2 = property(get_conta)
